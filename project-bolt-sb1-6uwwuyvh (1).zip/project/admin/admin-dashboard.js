// Admin Dashboard JavaScript
document.addEventListener('DOMContentLoaded', function() {
    checkAuthentication();
    initializeDashboard();
    initializeCharts();
    startRealTimeUpdates();
    initializeWebScraper();
    initializeProductManagement();
});

function checkAuthentication() {
    const session = localStorage.getItem('adminSession') || sessionStorage.getItem('adminSession');
    
    if (!session) {
        window.location.href = 'login.html';
        return;
    }
    
    const sessionData = JSON.parse(session);
    
    // Check if session is expired (for localStorage)
    if (sessionData.expires && Date.now() > sessionData.expires) {
        localStorage.removeItem('adminSession');
        window.location.href = 'login.html';
        return;
    }
}

function initializeDashboard() {
    // Initialize GSAP animations
    if (typeof gsap !== 'undefined') {
        gsap.from('.dashboard-card', {
            duration: 0.8,
            y: 50,
            opacity: 0,
            stagger: 0.1,
            ease: 'power2.out'
        });
    }
    
    // Initialize sidebar
    initializeSidebar();
    
    // Initialize theme toggle
    initializeTheme();
    
    // Initialize dark/light mode
    initializeDarkMode();
    
    // Initialize real-time updates
    startRealTimeUpdates();
    
    // Check maintenance mode status
    checkMaintenanceMode();
    
    // Add smooth scrolling
    document.documentElement.style.scrollBehavior = 'smooth';
}

function initializeDarkMode() {
    const darkModeToggle = document.getElementById('darkModeToggle');
    const currentTheme = localStorage.getItem('adminTheme') || 'dark';
    
    // Set initial theme
    document.body.setAttribute('data-theme', currentTheme);
    
    if (darkModeToggle) {
        darkModeToggle.checked = currentTheme === 'dark';
        
        darkModeToggle.addEventListener('change', function() {
            const newTheme = this.checked ? 'dark' : 'light';
            document.body.setAttribute('data-theme', newTheme);
            localStorage.setItem('adminTheme', newTheme);
            
            // Update charts theme
            updateChartsTheme(newTheme);
        });
    }
}

function initializeWebScraper() {
    const scrapeForm = document.getElementById('scrapeForm');
    if (scrapeForm) {
        scrapeForm.addEventListener('submit', handleWebScraping);
    }
    
    // Load scraped products
    loadScrapedProducts();
}

function handleWebScraping(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const url = formData.get('scrapeUrl');
    const category = formData.get('category');
    
    if (!url) {
        showNotification('Please enter a valid URL', 'error');
        return;
    }
    
    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Scraping...';
    submitBtn.disabled = true;
    
    // Simulate web scraping
    if (window.WebScraper) {
        window.WebScraper.scrapeWebsite(url, { category })
            .then(result => {
                if (result.success) {
                    showNotification(`Successfully scraped ${result.count} products!`, 'success');
                    loadScrapedProducts();
                } else {
                    showNotification(`Scraping failed: ${result.error}`, 'error');
                }
            })
            .catch(error => {
                showNotification(`Scraping error: ${error.message}`, 'error');
            })
            .finally(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
                e.target.reset();
            });
    } else {
        // Fallback simulation
        setTimeout(() => {
            const productCount = Math.floor(Math.random() * 10) + 5;
            showNotification(`Successfully scraped ${productCount} products!`, 'success');
            loadScrapedProducts();
            
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
            e.target.reset();
        }, 3000);
    }
}

function loadScrapedProducts() {
    const productsList = document.getElementById('scrapedProductsList');
    if (!productsList) return;
    
    // Get products from database or web scraper
    let products = [];
    
    if (window.Database) {
        products = window.Database.getProducts();
    } else if (window.WebScraper) {
        products = window.WebScraper.getScrapedProducts();
    }
    
    // Generate sample products if none exist
    if (products.length === 0) {
        products = generateSampleProducts();
    }
    
    productsList.innerHTML = '';
    
    products.slice(0, 10).forEach(product => {
        const productElement = document.createElement('div');
        productElement.className = 'product-item';
        productElement.innerHTML = `
            <div class="product-image">
                <img src="${product.image_url || product.image}" alt="${product.name}" loading="lazy">
            </div>
            <div class="product-details">
                <h4>${product.name}</h4>
                <p class="product-price">₹${product.price}</p>
                <p class="product-category">${product.category}</p>
                <p class="product-description">${(product.description || '').substring(0, 100)}...</p>
            </div>
            <div class="product-actions">
                <button class="btn btn-sm btn-primary" onclick="editProduct(${product.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteProduct(${product.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        
        productsList.appendChild(productElement);
    });
}

function generateSampleProducts() {
    return [
        {
            id: 1,
            name: 'Premium Corporate Gift Set',
            price: 2999,
            category: 'Corporate Gifts',
            description: 'Luxury corporate gift set with branded items',
            image: 'https://images.pexels.com/photos/6476585/pexels-photo-6476585.jpeg?auto=compress&cs=tinysrgb&w=400'
        },
        {
            id: 2,
            name: 'Executive Leather Portfolio',
            price: 1599,
            category: 'Office Accessories',
            description: 'Premium leather portfolio with compartments',
            image: 'https://images.pexels.com/photos/6476806/pexels-photo-6476806.jpeg?auto=compress&cs=tinysrgb&w=400'
        },
        {
            id: 3,
            name: 'Customized Trophy Set',
            price: 3499,
            category: 'Awards',
            description: 'Elegant trophy set for corporate awards',
            image: 'https://images.pexels.com/photos/6476807/pexels-photo-6476807.jpeg?auto=compress&cs=tinysrgb&w=400'
        }
    ];
}

function initializeProductManagement() {
    // Initialize product management features
    const exportBtn = document.getElementById('exportProducts');
    if (exportBtn) {
        exportBtn.addEventListener('click', exportProducts);
    }
    
    const importBtn = document.getElementById('importProducts');
    if (importBtn) {
        importBtn.addEventListener('click', () => {
            document.getElementById('importFile').click();
        });
    }
    
    const importFile = document.getElementById('importFile');
    if (importFile) {
        importFile.addEventListener('change', handleProductImport);
    }
}

function exportProducts() {
    let products = [];
    
    if (window.Database) {
        products = window.Database.getProducts();
    } else if (window.WebScraper) {
        products = window.WebScraper.getScrapedProducts();
    } else {
        products = generateSampleProducts();
    }
    
    const csv = convertToCSV(products);
    downloadCSV(csv, 'scraped_products.csv');
    
    showNotification(`Exported ${products.length} products to CSV`, 'success');
}

function convertToCSV(products) {
    if (!products.length) return '';
    
    const headers = ['Name', 'Price', 'Category', 'Description', 'Image URL'];
    const csvContent = [
        headers.join(','),
        ...products.map(product => [
            `"${product.name}"`,
            product.price,
            `"${product.category}"`,
            `"${(product.description || '').replace(/"/g, '""')}"`,
            `"${product.image_url || product.image}"`
        ].join(','))
    ].join('\n');
    
    return csvContent;
}

function downloadCSV(csv, filename) {
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
}

function handleProductImport(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(event) {
        try {
            const csv = event.target.result;
            const products = parseCSV(csv);
            
            // Store products in database
            if (window.Database) {
                products.forEach(product => {
                    window.Database.storeProduct(product);
                });
            }
            
            showNotification(`Imported ${products.length} products successfully!`, 'success');
            loadScrapedProducts();
        } catch (error) {
            showNotification(`Import failed: ${error.message}`, 'error');
        }
    };
    
    reader.readAsText(file);
}

function parseCSV(csv) {
    const lines = csv.split('\n');
    const headers = lines[0].split(',');
    const products = [];
    
    for (let i = 1; i < lines.length; i++) {
        if (lines[i].trim()) {
            const values = lines[i].split(',');
            const product = {};
            
            headers.forEach((header, index) => {
                const key = header.toLowerCase().replace(/\s+/g, '_');
                product[key] = values[index] ? values[index].replace(/"/g, '') : '';
            });
            
            if (product.name) {
                products.push({
                    name: product.name,
                    price: parseFloat(product.price) || 0,
                    category: product.category || 'Uncategorized',
                    description: product.description || '',
                    image_url: product.image_url || ''
                });
            }
        }
    }
    
    return products;
}

function editProduct(productId) {
    // Open product edit modal
    showNotification('Product edit feature coming soon!', 'info');
}

function deleteProduct(productId) {
    if (confirm('Are you sure you want to delete this product?')) {
        if (window.Database) {
            window.Database.deleteProduct(productId);
        }
        
        showNotification('Product deleted successfully!', 'success');
        loadScrapedProducts();
    }
}

function startRealTimeUpdates() {
    // Update dashboard metrics every 10 seconds
    setInterval(updateDashboardMetrics, 10000);
    
    // Update charts every 30 seconds
    setInterval(updateChartData, 30000);
    
    // Update visitor data every 5 seconds
    setInterval(updateVisitorData, 5000);
    
    // Update security alerts every 5 seconds
    setInterval(updateSecurityAlerts, 5000);
    
    // Initial update
    updateDashboardMetrics();
}

function updateVisitorData() {
    // Get real visitor data from database
    if (window.Database) {
        const stats = window.Database.getVisitorStats();
        
        const totalVisitors = document.getElementById('totalVisitors');
        const activeUsers = document.getElementById('activeUsers');
        const todayVisitors = document.getElementById('todayVisitors');
        
        if (totalVisitors) totalVisitors.textContent = stats.total.toLocaleString();
        if (activeUsers) activeUsers.textContent = stats.active;
        if (todayVisitors) todayVisitors.textContent = stats.today;
    }
}

function updateDashboardMetrics() {
    // Update uptime
    const uptimeMetric = document.getElementById('uptimeMetric');
    if (uptimeMetric) {
        const uptime = (99.0 + Math.random() * 0.9).toFixed(1);
        uptimeMetric.textContent = uptime + '%';
    }
    
    // Update load time
    const loadTimeMetric = document.getElementById('loadTimeMetric');
    if (loadTimeMetric) {
        const loadTime = (0.8 + Math.random() * 0.8).toFixed(1);
        loadTimeMetric.textContent = `Load Time: ${loadTime}s`;
    }
    
    // Update visitors
    const totalVisitors = document.getElementById('totalVisitors');
    if (totalVisitors) {
        const current = parseInt(totalVisitors.textContent.replace(/,/g, '')) || 1000;
        const increment = Math.floor(Math.random() * 10) + 1;
        totalVisitors.textContent = (current + increment).toLocaleString();
    }
    
    // Update active users
    const activeUsers = document.getElementById('activeUsers');
    if (activeUsers) {
        const users = Math.floor(50 + Math.random() * 150);
        activeUsers.textContent = users;
    }
    
    // Update security metrics
    updateSecurityMetrics();
    
    // Update system resources
    updateSystemResources();
}

function updateSecurityMetrics() {
    if (window.aiSecurity) {
        const metrics = window.aiSecurity.getSecurityMetrics();
        const status = window.aiSecurity.getSecurityStatus();
        
        // Update blocked threats
        const blockedThreats = document.getElementById('blockedThreats');
        if (blockedThreats) {
            blockedThreats.textContent = `Blocked Threats: ${metrics.totalThreatsBlocked}`;
        }
        
        // Update security status
        const securityStatus = document.getElementById('securityStatus');
        const securityIcon = document.getElementById('securityIcon');
        if (securityStatus && securityIcon) {
            const threatLevel = status.threatLevel;
            securityStatus.textContent = threatLevel;
            
            // Update icon and color based on threat level
            const statusIndicator = securityStatus.closest('.status-indicator');
            statusIndicator.className = 'status-indicator';
            
            if (threatLevel === 'LOW') {
                statusIndicator.classList.add('secure');
                securityIcon.className = 'fas fa-check-circle';
            } else if (threatLevel === 'MEDIUM') {
                statusIndicator.classList.add('warning');
                securityIcon.className = 'fas fa-exclamation-triangle';
            } else {
                statusIndicator.classList.add('danger');
                securityIcon.className = 'fas fa-times-circle';
            }
        }
        
        // Update last scan time
        const lastScan = document.getElementById('lastScan');
        if (lastScan) {
            const now = new Date();
            const scanTime = new Date(now.getTime() - Math.random() * 300000); // Random time within last 5 minutes
            const timeDiff = Math.floor((now - scanTime) / 60000);
            lastScan.textContent = `Last Scan: ${timeDiff} min ago`;
        }
    }
}

function updateSystemResources() {
    // Update CPU usage
    const cpuUsage = document.getElementById('cpuUsage');
    if (cpuUsage) {
        const usage = Math.floor(30 + Math.random() * 40);
        cpuUsage.style.width = usage + '%';
        cpuUsage.nextElementSibling.textContent = usage + '%';
        
        // Change color based on usage
        if (usage > 80) {
            cpuUsage.style.background = '#e74c3c';
        } else if (usage > 60) {
            cpuUsage.style.background = '#f39c12';
        } else {
            cpuUsage.style.background = '#27ae60';
        }
    }
    
    // Update Memory usage
    const memoryUsage = document.getElementById('memoryUsage');
    if (memoryUsage) {
        const usage = Math.floor(40 + Math.random() * 35);
        memoryUsage.style.width = usage + '%';
        memoryUsage.nextElementSibling.textContent = usage + '%';
        
        if (usage > 80) {
            memoryUsage.style.background = '#e74c3c';
        } else if (usage > 60) {
            memoryUsage.style.background = '#f39c12';
        } else {
            memoryUsage.style.background = '#27ae60';
        }
    }
    
    // Update Storage usage
    const storageUsage = document.getElementById('storageUsage');
    if (storageUsage) {
        const usage = Math.floor(25 + Math.random() * 30);
        storageUsage.style.width = usage + '%';
        storageUsage.nextElementSibling.textContent = usage + '%';
        
        if (usage > 80) {
            storageUsage.style.background = '#e74c3c';
        } else if (usage > 60) {
            storageUsage.style.background = '#f39c12';
        } else {
            storageUsage.style.background = '#27ae60';
        }
    }
}

function updateSecurityAlerts() {
    const alertsList = document.getElementById('securityAlerts');
    if (!alertsList) return;
    
    // Get alerts from AI security system
    let alerts = [];
    if (window.aiSecurity) {
        const storedAlerts = JSON.parse(localStorage.getItem('securityAlerts') || '[]');
        alerts = storedAlerts.slice(0, 5); // Show only last 5 alerts
    }
    
    // If no real alerts, show simulated ones
    if (alerts.length === 0) {
        alerts = [
            {
                type: 'System Scan',
                message: 'Automated security scan completed',
                severity: 'low',
                timestamp: new Date(Date.now() - 120000)
            },
            {
                type: 'IP Block',
                message: 'Suspicious IP address blocked',
                severity: 'medium',
                timestamp: new Date(Date.now() - 900000)
            }
        ];
    }
    
    // Update alerts display
    alertsList.innerHTML = '';
    alerts.forEach(alert => {
        const alertElement = document.createElement('div');
        alertElement.className = `alert-item ${alert.severity || 'low'}`;
        
        const icon = alert.severity === 'high' ? 'fas fa-exclamation-circle' :
                    alert.severity === 'medium' ? 'fas fa-exclamation-triangle' :
                    'fas fa-info-circle';
        
        const timeAgo = getTimeAgo(alert.timestamp);
        
        alertElement.innerHTML = `
            <i class="${icon}"></i>
            <span>${alert.message || alert.type}</span>
            <small>${timeAgo}</small>
        `;
        
        alertsList.appendChild(alertElement);
    });
}

function getTimeAgo(timestamp) {
    const now = new Date();
    const time = new Date(timestamp);
    const diffInMinutes = Math.floor((now - time) / 60000);
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes} min ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours} hour${diffInHours > 1 ? 's' : ''} ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} day${diffInDays > 1 ? 's' : ''} ago`;
}

function initializeSidebar() {
    const menuItems = document.querySelectorAll('.menu-item a');
    
    menuItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active class from all items
            document.querySelectorAll('.menu-item').forEach(mi => mi.classList.remove('active'));
            
            // Add active class to clicked item
            this.parentElement.classList.add('active');
            
            // Get section to show
            const sectionId = this.getAttribute('href').substring(1);
            showSection(sectionId);
        });
    });
}

function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.admin-section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show selected section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
        
        // Update page title
        const pageTitle = document.getElementById('pageTitle');
        if (pageTitle) {
            pageTitle.textContent = sectionId.charAt(0).toUpperCase() + sectionId.slice(1);
        }
        
        // Animate section entrance
        if (typeof gsap !== 'undefined') {
            gsap.from(targetSection, {
                duration: 0.5,
                opacity: 0,
                y: 20,
                ease: 'power2.out'
            });
        }
    }
}

function toggleSidebar() {
    const sidebar = document.querySelector('.admin-sidebar');
    sidebar.classList.toggle('open');
}

function initializeTheme() {
    const themeToggle = document.querySelector('.theme-toggle button');
    const currentTheme = localStorage.getItem('adminTheme') || 'light';
    
    if (currentTheme === 'dark') {
        document.body.classList.add('dark-mode');
        themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    }
    
    themeToggle.addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        
        if (document.body.classList.contains('dark-mode')) {
            localStorage.setItem('adminTheme', 'dark');
            this.innerHTML = '<i class="fas fa-sun"></i>';
        } else {
            localStorage.setItem('adminTheme', 'light');
            this.innerHTML = '<i class="fas fa-moon"></i>';
        }
    });
}

function toggleTheme() {
    const themeToggle = document.querySelector('.theme-toggle button');
    themeToggle.click();
}

function updateChartsTheme(theme) {
    const isDark = theme === 'dark';
    const textColor = isDark ? '#ffffff' : '#333333';
    const gridColor = isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)';
    
    // Update all charts with new theme
    if (window.analyticsChart) {
        window.analyticsChart.options.scales.x.ticks.color = textColor;
        window.analyticsChart.options.scales.y.ticks.color = textColor;
        window.analyticsChart.options.scales.x.grid.color = gridColor;
        window.analyticsChart.options.scales.y.grid.color = gridColor;
        window.analyticsChart.update();
    }
    
    if (window.trafficChart) {
        window.trafficChart.options.plugins.legend.labels.color = textColor;
        window.trafficChart.update();
    }
    
    if (window.conversionChart) {
        window.conversionChart.options.scales.x.ticks.color = textColor;
        window.conversionChart.options.scales.y.ticks.color = textColor;
        window.conversionChart.options.scales.x.grid.color = gridColor;
        window.conversionChart.options.scales.y.grid.color = gridColor;
        window.conversionChart.update();
    }
}

function initializeCharts() {
    // Analytics Chart
    const analyticsCtx = document.getElementById('analyticsChart');
    if (analyticsCtx && typeof Chart !== 'undefined') {
        window.analyticsChart = new Chart(analyticsCtx, {
            type: 'line',
            data: {
                labels: generateTimeLabels(),
                datasets: [{
                    label: 'Website Traffic',
                    data: generateTrafficData(),
                    borderColor: '#C4B454',
                    backgroundColor: 'rgba(196, 180, 84, 0.1)',
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: '#C4B454',
                    pointBorderColor: '#D4AC0D',
                    pointHoverRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    duration: 2000,
                    easing: 'easeInOutQuart'
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 245, 255, 0.9)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#666666'
                        }
                    }
                }
            }
        });
    }
    
    // Traffic Chart
    const trafficCtx = document.getElementById('trafficChart');
    if (trafficCtx && typeof Chart !== 'undefined') {
        window.trafficChart = new Chart(trafficCtx, {
            type: 'doughnut',
            data: {
                labels: ['Direct', 'Organic', 'Social', 'Referral'],
                datasets: [{
                    data: generateTrafficSourceData(),
                    backgroundColor: ['#C4B454', '#2F4059', '#27ae60', '#e74c3c'],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                animation: {
                    animateRotate: true,
                    duration: 2000
                },
                plugins: {
                    legend: {
                        position: 'bottom'
                    },
                    tooltip: {
                        backgroundColor: 'rgba(47, 64, 89, 0.9)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff'
                    }
                }
            }
        });
    }
    
    // Conversion Chart
    const conversionCtx = document.getElementById('conversionChart');
    if (conversionCtx && typeof Chart !== 'undefined') {
        window.conversionChart = new Chart(conversionCtx, {
            type: 'bar',
            data: {
                labels: ['Consultations', 'Inquiries', 'Downloads', 'Subscriptions'],
                datasets: [{
                    label: 'Conversions',
                    data: generateConversionData(),
                    backgroundColor: '#C4B454',
                    borderColor: '#D4AC0D',
                    borderWidth: 1,
                    borderRadius: 5
                }]
            },
            options: {
                responsive: true,
                animation: {
                    duration: 2000,
                    easing: 'easeOutBounce'
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(196, 180, 84, 0.9)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // Real-time Visitors Chart
    const visitorsCtx = document.getElementById('visitorsChart');
    if (visitorsCtx && typeof Chart !== 'undefined') {
        window.visitorsChart = new Chart(visitorsCtx, {
            type: 'line',
            data: {
                labels: generateTimeLabels(),
                datasets: [{
                    label: 'Active Visitors',
                    data: generateVisitorData(),
                    borderColor: '#00f5ff',
                    backgroundColor: 'rgba(0, 245, 255, 0.1)',
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: '#00f5ff',
                    pointBorderColor: '#ffffff',
                    pointHoverRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    duration: 1000,
                    easing: 'easeInOutQuart'
                },
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }
}

function generateTimeLabels() {
    const labels = [];
    const now = new Date();
    for (let i = 11; i >= 0; i--) {
        const time = new Date(now.getTime() - i * 60000); // Every minute
        labels.push(time.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' }));
    }
    return labels;
}

function generateTrafficData() {
    const data = [];
    for (let i = 0; i < 12; i++) {
        data.push(Math.floor(800 + Math.random() * 400));
    }
    return data;
}

function generateVisitorData() {
    const data = [];
    for (let i = 0; i < 12; i++) {
        data.push(Math.floor(20 + Math.random() * 80));
    }
    return data;
}

function generateTrafficSourceData() {
    return [
        Math.floor(40 + Math.random() * 20),
        Math.floor(25 + Math.random() * 15),
        Math.floor(10 + Math.random() * 10),
        Math.floor(5 + Math.random() * 10)
    ];
}

function generateConversionData() {
    return [
        Math.floor(50 + Math.random() * 30),
        Math.floor(30 + Math.random() * 25),
        Math.floor(60 + Math.random() * 40),
        Math.floor(15 + Math.random() * 20)
    ];
}

function updateChartData() {
    // Update analytics chart
    if (window.analyticsChart) {
        const newData = generateTrafficData();
        const newLabels = generateTimeLabels();
        
        window.analyticsChart.data.labels = newLabels;
        window.analyticsChart.data.datasets[0].data = newData;
        window.analyticsChart.update('active');
    }
    
    // Update traffic chart
    if (window.trafficChart) {
        const newData = generateTrafficSourceData();
        window.trafficChart.data.datasets[0].data = newData;
        window.trafficChart.update('active');
    }
    
    // Update conversion chart
    if (window.conversionChart) {
        const newData = generateConversionData();
        window.conversionChart.data.datasets[0].data = newData;
        window.conversionChart.update('active');
    }
    
    // Update visitors chart
    if (window.visitorsChart) {
        const newData = generateVisitorData();
        const newLabels = generateTimeLabels();
        
        window.visitorsChart.data.labels = newLabels;
        window.visitorsChart.data.datasets[0].data = newData;
        window.visitorsChart.update('active');
    }
}

// Maintenance Mode Functions
function checkMaintenanceMode() {
    const maintenanceMode = localStorage.getItem('maintenanceMode');
    const checkbox = document.getElementById('maintenanceMode');
    const indicator = document.getElementById('maintenanceIndicator');
    const text = document.getElementById('maintenanceText');
    
    if (maintenanceMode === 'true') {
        if (checkbox) checkbox.checked = true;
        if (indicator) {
            indicator.style.color = '#e74c3c';
            indicator.className = 'fas fa-circle';
        }
        if (text) text.textContent = 'Enabled';
    } else {
        if (checkbox) checkbox.checked = false;
        if (indicator) {
            indicator.style.color = '#27ae60';
            indicator.className = 'fas fa-circle';
        }
        if (text) text.textContent = 'Disabled';
    }
}

function toggleMaintenanceMode(checkbox) {
    const isEnabled = checkbox.checked;
    const indicator = document.getElementById('maintenanceIndicator');
    const text = document.getElementById('maintenanceText');
    
    if (isEnabled) {
        if (confirm('Are you sure you want to enable maintenance mode? This will restrict access to the website.')) {
            localStorage.setItem('maintenanceMode', 'true');
            if (indicator) {
                indicator.style.color = '#e74c3c';
            }
            if (text) text.textContent = 'Enabled';
            showNotification('Maintenance mode has been enabled', 'warning');
            
            // Log the action
            if (window.aiSecurity) {
                window.aiSecurity.sendSystemAlert({
                    type: 'Maintenance Mode',
                    message: 'Maintenance mode enabled by administrator',
                    timestamp: new Date(),
                    severity: 'medium'
                });
            }
        } else {
            checkbox.checked = false;
        }
    } else {
        localStorage.setItem('maintenanceMode', 'false');
        if (indicator) {
            indicator.style.color = '#27ae60';
        }
        if (text) text.textContent = 'Disabled';
        showNotification('Maintenance mode has been disabled', 'success');
        
        // Log the action
        if (window.aiSecurity) {
            window.aiSecurity.sendSystemAlert({
                type: 'Maintenance Mode',
                message: 'Maintenance mode disabled by administrator',
                timestamp: new Date(),
                severity: 'low'
            });
        }
    }
}

// Enhanced notification system
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.admin-notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Create notification
    const notification = document.createElement('div');
    notification.className = `admin-notification admin-notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${getNotificationIcon(type)}"></i>
            <span>${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${getNotificationColor(type)};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        z-index: 10000;
        max-width: 400px;
        animation: slideInRight 0.3s ease;
        border: 1px solid rgba(255,255,255,0.2);
    `;
    
    notification.querySelector('.notification-content').style.cssText = `
        display: flex;
        align-items: center;
        gap: 0.75rem;
    `;
    
    notification.querySelector('.notification-close').style.cssText = `
        background: none;
        border: none;
        color: white;
        cursor: pointer;
        margin-left: auto;
        opacity: 0.8;
        transition: opacity 0.3s ease;
        padding: 0.25rem;
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

function getNotificationIcon(type) {
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    return icons[type] || icons.info;
}

function getNotificationColor(type) {
    const colors = {
        success: '#4ecdc4',
        error: '#ff6b6b',
        warning: '#f1c40f',
        info: '#00f5ff'
    };
    return colors[type] || colors.info;
}

function logout() {
    // Clear session data
    localStorage.removeItem('adminSession');
    sessionStorage.removeItem('adminSession');
    localStorage.removeItem('adminTheme');
    
    // Show logout animation
    if (typeof gsap !== 'undefined') {
        gsap.to('.admin-container', {
            duration: 0.5,
            opacity: 0,
            scale: 0.9,
            ease: 'power2.in',
            onComplete: function() {
                window.location.href = 'login.html';
            }
        });
    } else {
        window.location.href = 'login.html';
    }
}

// Add notification animations
const notificationStyle = document.createElement('style');
notificationStyle.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .live-indicator {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-size: 0.8rem;
        color: #27ae60;
        font-weight: 600;
    }
    
    .live-dot {
        width: 8px;
        height: 8px;
        background: #27ae60;
        border-radius: 50%;
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.5; }
        100% { opacity: 1; }
    }
    
    .alert-item {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.5rem;
        margin-bottom: 0.5rem;
        border-radius: 5px;
        font-size: 0.9rem;
    }
    
    .alert-item.low {
        background: rgba(39, 174, 96, 0.1);
        border-left: 3px solid #27ae60;
    }
    
    .alert-item.medium {
        background: rgba(243, 156, 18, 0.1);
        border-left: 3px solid #f39c12;
    }
    
    .alert-item.high {
        background: rgba(231, 76, 60, 0.1);
        border-left: 3px solid #e74c3c;
    }
    
    .alert-item small {
        margin-left: auto;
        opacity: 0.7;
    }
    
    .resource-metrics {
        display: flex;
        flex-direction: column;
        gap: 1rem;
    }
    
    .resource-item {
        display: flex;
        align-items: center;
        gap: 1rem;
    }
    
    .resource-label {
        min-width: 80px;
        font-size: 0.9rem;
        color: #666;
    }
    
    .resource-bar {
        flex: 1;
        height: 8px;
        background: #f0f0f0;
        border-radius: 4px;
        overflow: hidden;
    }
    
    .resource-fill {
        height: 100%;
        background: #27ae60;
        border-radius: 4px;
        transition: width 0.3s ease, background-color 0.3s ease;
    }
    
    .resource-value {
        min-width: 40px;
        text-align: right;
        font-size: 0.9rem;
        font-weight: 600;
    }
    
    .maintenance-status {
        margin-bottom: 1rem;
        padding: 1rem;
        background: #f8f9fa;
        border-radius: 8px;
        border: 1px solid #e9ecef;
    }
    
    .maintenance-options {
        margin-top: 1rem;
        padding-top: 1rem;
        border-top: 1px solid #e9ecef;
    }
    
    .option-group {
        margin-bottom: 1rem;
    }
    
    .option-group label {
        display: block;
        margin-bottom: 0.5rem;
        cursor: pointer;
    }
    
    .maintenance-message textarea {
        width: 100%;
        min-height: 80px;
        padding: 0.5rem;
        border: 1px solid #ddd;
        border-radius: 4px;
        resize: vertical;
    }
    
    .status-indicator.warning {
        background: rgba(243, 156, 18, 0.1);
        color: #f39c12;
    }
    
    .status-indicator.danger {
        background: rgba(231, 76, 60, 0.1);
        color: #e74c3c;
    }
    
    /* Dark/Light mode styles */
    [data-theme="light"] {
        --admin-bg: #ffffff;
        --admin-text: #333333;
        --admin-card-bg: #f8f9fa;
        --admin-border: #e9ecef;
    }
    
    [data-theme="dark"] {
        --admin-bg: #1a1a1a;
        --admin-text: #ffffff;
        --admin-card-bg: #2d2d2d;
        --admin-border: #404040;
    }
    
    .admin-body {
        background: var(--admin-bg);
        color: var(--admin-text);
    }
    
    .dashboard-card {
        background: var(--admin-card-bg);
        border-color: var(--admin-border);
    }
    
    .admin-header {
        background: var(--admin-card-bg);
        border-color: var(--admin-border);
    }
    
    /* Product management styles */
    .product-item {
        display: flex;
        align-items: center;
        gap: 1rem;
        padding: 1rem;
        background: var(--admin-card-bg);
        border: 1px solid var(--admin-border);
        border-radius: 10px;
        margin-bottom: 1rem;
        transition: all 0.3s ease;
    }
    
    .product-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    .product-image {
        width: 80px;
        height: 80px;
        border-radius: 8px;
        overflow: hidden;
        flex-shrink: 0;
    }
    
    .product-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .product-details {
        flex: 1;
    }
    
    .product-details h4 {
        margin: 0 0 0.5rem 0;
        color: var(--admin-text);
    }
    
    .product-price {
        font-weight: bold;
        color: #00f5ff;
        margin: 0.25rem 0;
    }
    
    .product-category {
        font-size: 0.9rem;
        color: #666;
        margin: 0.25rem 0;
    }
    
    .product-description {
        font-size: 0.8rem;
        color: #999;
        margin: 0.25rem 0;
    }
    
    .product-actions {
        display: flex;
        gap: 0.5rem;
    }
    
    .btn-sm {
        padding: 0.5rem;
        font-size: 0.8rem;
        min-width: auto;
    }
    
    /* Enhanced button effects */
    .btn {
        position: relative;
        overflow: hidden;
        transition: all 0.3s ease;
    }
    
    .btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    
    .btn::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
        transition: left 0.5s;
    }
    
    .btn:hover::before {
        left: 100%;
    }
    
    /* Notification animations */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .admin-notification {
        animation: fadeInUp 0.5s ease;
    }
    
    /* Loading animations */
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    .fa-spinner {
        animation: spin 1s linear infinite;
    }
    
    /* Card hover effects */
    .dashboard-card {
        transition: all 0.3s ease;
    }
    
    .dashboard-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    }
    
    /* Progress bar animations */
    .resource-fill {
        animation: fillProgress 1s ease-in-out;
    }
    
    @keyframes fillProgress {
        from { width: 0; }
        to { width: var(--progress-width); }
    }
    
    /* Chart container animations */
    .chart-container {
        opacity: 0;
        animation: fadeIn 1s ease forwards;
    }
    
    @keyframes fadeIn {
        to { opacity: 1; }
    }
    
    /* Responsive animations */
    @media (max-width: 768px) {
        .dashboard-card {
            animation-delay: 0.1s;
        }
        
        .btn {
            transform: none;
        }
        
        .btn:hover {
            transform: none;
        }
    }
    
    /* Success/Error state animations */
    .success-pulse {
        animation: successPulse 0.6s ease;
    }
    
    @keyframes successPulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); background-color: #4ecdc4; }
        100% { transform: scale(1); }
    }
    
    .error-shake {
        animation: errorShake 0.6s ease;
    }
    
    @keyframes errorShake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-5px); }
        75% { transform: translateX(5px); }
    }
    
    /* Typing animation for notifications */
    .typing-animation {
        overflow: hidden;
        border-right: 2px solid;
        white-space: nowrap;
        animation: typing 2s steps(40, end), blink-caret 0.75s step-end infinite;
    }
    
    @keyframes typing {
        from { width: 0; }
        to { width: 100%; }
    }
    
    @keyframes blink-caret {
        from, to { border-color: transparent; }
        50% { border-color: currentColor; }
    }
`;
document.head.appendChild(notificationStyle);

// Voice interface (basic implementation)
if ('webkitSpeechRecognition' in window) {
    const recognition = new webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
    
    recognition.onresult = function(event) {
        const command = event.results[0][0].transcript.toLowerCase();
        handleVoiceCommand(command);
    };
    
    // Add voice activation button (could be added to header)
    function startVoiceRecognition() {
        recognition.start();
        showNotification('Listening for voice command...', 'info');
    }
    
    function handleVoiceCommand(command) {
        if (command.includes('dashboard')) {
            showSection('dashboard');
        } else if (command.includes('analytics')) {
            showSection('analytics');
        } else if (command.includes('security')) {
            showSection('security');
        } else if (command.includes('logout')) {
            logout();
        } else {
            showNotification('Command not recognized', 'error');
        }
    }
}