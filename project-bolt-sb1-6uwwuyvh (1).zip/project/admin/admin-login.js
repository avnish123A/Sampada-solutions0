// Admin Login JavaScript
document.addEventListener('DOMContentLoaded', function() {
    initializeLogin();
    startSecurityMonitoring();
});

function initializeLogin() {
    const loginForm = document.getElementById('adminLoginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Add input animations
    const inputs = document.querySelectorAll('input');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });
        
        input.addEventListener('blur', function() {
            if (!this.value) {
                this.parentElement.classList.remove('focused');
            }
        });
    });
}

function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const remember = document.getElementById('remember').checked;
    
    // Validate credentials
    if (email === 'studenthubinc@gmail.com' && password === 'avnish@123A') {
        // Show loading state
        const submitBtn = document.querySelector('.login-btn');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>Authenticating...</span>';
        submitBtn.disabled = true;
        
        // Simulate authentication process
        setTimeout(() => {
            // Store session
            if (remember) {
                localStorage.setItem('adminSession', JSON.stringify({
                    email: email,
                    loginTime: Date.now(),
                    expires: Date.now() + (30 * 24 * 60 * 60 * 1000) // 30 days
                }));
            } else {
                sessionStorage.setItem('adminSession', JSON.stringify({
                    email: email,
                    loginTime: Date.now()
                }));
            }
            
            // Redirect to dashboard
            window.location.href = 'dashboard.html';
        }, 2000);
    } else {
        // Show error
        showError('Invalid credentials. Please check your email and password.');
        
        // Add shake animation
        const loginCard = document.querySelector('.login-card');
        loginCard.style.animation = 'shake 0.5s ease-in-out';
        setTimeout(() => {
            loginCard.style.animation = '';
        }, 500);
    }
}

function togglePassword() {
    const passwordInput = document.getElementById('password');
    const toggleBtn = document.querySelector('.toggle-password i');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleBtn.className = 'fas fa-eye-slash';
    } else {
        passwordInput.type = 'password';
        toggleBtn.className = 'fas fa-eye';
    }
}

function showError(message) {
    // Remove existing error
    const existingError = document.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }
    
    // Create error element
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.style.cssText = `
        background: #e74c3c;
        color: white;
        padding: 1rem;
        border-radius: 8px;
        margin-top: 1rem;
        text-align: center;
        animation: slideDown 0.3s ease;
    `;
    errorDiv.textContent = message;
    
    // Add to form
    const form = document.querySelector('.login-form');
    form.appendChild(errorDiv);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (errorDiv.parentNode) {
            errorDiv.remove();
        }
    }, 5000);
}

function startSecurityMonitoring() {
    // Simulate real-time security metrics
    updateSecurityMetrics();
    setInterval(updateSecurityMetrics, 5000);
}

function updateSecurityMetrics() {
    const threatLevel = document.getElementById('threatLevel');
    const activeUsers = document.getElementById('activeUsers');
    const systemHealth = document.getElementById('systemHealth');
    
    if (threatLevel) {
        const threats = ['LOW', 'MEDIUM', 'HIGH'];
        const colors = ['#27ae60', '#f39c12', '#e74c3c'];
        const randomThreat = Math.random() > 0.9 ? 1 : 0; // 90% chance of LOW
        
        threatLevel.textContent = threats[randomThreat];
        threatLevel.style.color = colors[randomThreat];
    }
    
    if (activeUsers) {
        activeUsers.textContent = Math.floor(Math.random() * 5) + 1;
    }
    
    if (systemHealth) {
        const health = Math.floor(Math.random() * 5) + 95;
        systemHealth.textContent = health + '%';
        systemHealth.style.color = health > 95 ? '#27ae60' : '#f39c12';
    }
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-10px); }
        75% { transform: translateX(10px); }
    }
    
    @keyframes slideDown {
        from {
            opacity: 0;
            transform: translateY(-20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .focused {
        transform: scale(1.02);
        transition: transform 0.3s ease;
    }
`;
document.head.appendChild(style);