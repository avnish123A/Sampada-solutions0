// Enhanced Performance Optimizer
class PerformanceOptimizer {
    constructor() {
        this.metrics = {
            loadTime: 0,
            fcp: 0, // First Contentful Paint
            lcp: 0, // Largest Contentful Paint
            fid: 0, // First Input Delay
            cls: 0  // Cumulative Layout Shift
        };
        
        this.optimizations = {
            lazyLoading: true,
            imageCompression: true,
            caching: true,
            minification: true,
            http3: true,
            preloading: true,
            compression: true
        };
        
        this.initialize();
    }
    
    initialize() {
        this.setupPerformanceMonitoring();
        this.enableLazyLoading();
        this.optimizeImages();
        this.setupCaching();
        this.enableHTTP3();
        this.monitorCoreWebVitals();
        this.optimizeResourceLoading();
        
        console.log('⚡ Performance Optimizer initialized');
    }
    
    // Core Web Vitals Monitoring
    monitorCoreWebVitals() {
        // Largest Contentful Paint (LCP)
        if ('PerformanceObserver' in window) {
            new PerformanceObserver((entryList) => {
                const entries = entryList.getEntries();
                const lastEntry = entries[entries.length - 1];
                this.metrics.lcp = lastEntry.startTime;
                this.checkLCPThreshold();
            }).observe({ entryTypes: ['largest-contentful-paint'] });
            
            // First Input Delay (FID)
            new PerformanceObserver((entryList) => {
                const entries = entryList.getEntries();
                entries.forEach(entry => {
                    this.metrics.fid = entry.processingStart - entry.startTime;
                    this.checkFIDThreshold();
                });
            }).observe({ entryTypes: ['first-input'] });
            
            // Cumulative Layout Shift (CLS)
            new PerformanceObserver((entryList) => {
                const entries = entryList.getEntries();
                entries.forEach(entry => {
                    if (!entry.hadRecentInput) {
                        this.metrics.cls += entry.value;
                    }
                });
                this.checkCLSThreshold();
            }).observe({ entryTypes: ['layout-shift'] });
            
            // First Contentful Paint (FCP)
            new PerformanceObserver((entryList) => {
                const entries = entryList.getEntries();
                entries.forEach(entry => {
                    if (entry.name === 'first-contentful-paint') {
                        this.metrics.fcp = entry.startTime;
                        this.checkFCPThreshold();
                    }
                });
            }).observe({ entryTypes: ['paint'] });
        }
    }
    
    checkLCPThreshold() {
        if (this.metrics.lcp > 2500) {
            console.warn('⚠️ LCP is above 2.5s threshold:', this.metrics.lcp);
            this.optimizeLCP();
        } else {
            console.log('✅ LCP is within good threshold:', this.metrics.lcp);
        }
    }
    
    checkFIDThreshold() {
        if (this.metrics.fid > 100) {
            console.warn('⚠️ FID is above 100ms threshold:', this.metrics.fid);
            this.optimizeFID();
        } else {
            console.log('✅ FID is within good threshold:', this.metrics.fid);
        }
    }
    
    checkCLSThreshold() {
        if (this.metrics.cls > 0.1) {
            console.warn('⚠️ CLS is above 0.1 threshold:', this.metrics.cls);
            this.optimizeCLS();
        } else {
            console.log('✅ CLS is within good threshold:', this.metrics.cls);
        }
    }
    
    checkFCPThreshold() {
        if (this.metrics.fcp > 1800) {
            console.warn('⚠️ FCP is above 1.8s threshold:', this.metrics.fcp);
            this.optimizeFCP();
        } else {
            console.log('✅ FCP is within good threshold:', this.metrics.fcp);
        }
    }
    
    // Performance Optimizations
    optimizeLCP() {
        this.preloadCriticalResources();
        this.optimizeCriticalRenderingPath();
        this.enableResourceHints();
    }
    
    optimizeFID() {
        this.deferNonCriticalJavaScript();
        this.useWebWorkers();
        this.optimizeEventHandlers();
    }
    
    optimizeCLS() {
        this.setImageDimensions();
        this.reserveSpaceForAds();
        this.avoidDynamicContent();
    }
    
    optimizeFCP() {
        this.inlineCriticalCSS();
        this.eliminateRenderBlockingResources();
        this.optimizeFonts();
    }
    
    // Resource Loading Optimization
    optimizeResourceLoading() {
        this.implementResourcePriorities();
        this.enablePreloading();
        this.optimizeScriptLoading();
        this.implementServiceWorker();
    }
    
    implementResourcePriorities() {
        // Set resource priorities
        const criticalResources = document.querySelectorAll('link[rel="stylesheet"], script[src]');
        criticalResources.forEach(resource => {
            if (resource.href && resource.href.includes('styles.css')) {
                resource.setAttribute('importance', 'high');
            } else if (resource.src && resource.src.includes('script.js')) {
                resource.setAttribute('importance', 'high');
            }
        });
        
        console.log('⚡ Resource priorities optimized');
    }
    
    enablePreloading() {
        const criticalResources = [
            { href: 'src/styles.css', as: 'style' },
            { href: 'src/script.js', as: 'script' },
            { href: 'https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Poppins:wght@300;400;500;600;700&display=swap', as: 'style' }
        ];
        
        criticalResources.forEach(resource => {
            const link = document.createElement('link');
            link.rel = 'preload';
            link.href = resource.href;
            link.as = resource.as;
            if (resource.as === 'style') {
                link.onload = function() { this.rel = 'stylesheet'; };
            }
            document.head.appendChild(link);
        });
        
        console.log('🚀 Critical resources preloaded');
    }
    
    optimizeScriptLoading() {
        // Defer non-critical scripts
        const scripts = document.querySelectorAll('script[src]');
        scripts.forEach(script => {
            if (!script.src.includes('critical') && !script.async && !script.defer) {
                script.defer = true;
            }
        });
        
        console.log('📜 Script loading optimized');
    }
    
    // Lazy Loading Implementation
    enableLazyLoading() {
        this.lazyLoadImages();
        this.lazyLoadComponents();
        this.lazyLoadScripts();
    }
    
    lazyLoadImages() {
        const images = document.querySelectorAll('img[data-src]');
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.remove('lazy');
                    observer.unobserve(img);
                }
            });
        }, {
            rootMargin: '50px'
        });
        
        images.forEach(img => imageObserver.observe(img));
        
        // Also handle regular images with loading="lazy"
        const regularImages = document.querySelectorAll('img:not([data-src])');
        regularImages.forEach(img => {
            if (!img.hasAttribute('loading')) {
                img.setAttribute('loading', 'lazy');
            }
        });
        
        console.log('🖼️ Image lazy loading enabled');
    }
    
    lazyLoadComponents() {
        const components = document.querySelectorAll('[data-lazy-component]');
        const componentObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const component = entry.target;
                    const componentName = component.dataset.lazyComponent;
                    this.loadComponent(componentName, component);
                }
            });
        });
        
        components.forEach(component => componentObserver.observe(component));
    }
    
    loadComponent(componentName, element) {
        // Simulate component loading
        console.log(`🔄 Loading component: ${componentName}`);
        
        setTimeout(() => {
            element.innerHTML = `<div class="loaded-component">${componentName} loaded!</div>`;
            console.log(`✅ Component loaded: ${componentName}`);
        }, 500);
    }
    
    lazyLoadScripts() {
        const scripts = document.querySelectorAll('script[data-lazy]');
        scripts.forEach(script => {
            const newScript = document.createElement('script');
            newScript.src = script.dataset.src;
            newScript.async = true;
            document.head.appendChild(newScript);
        });
    }
    
    // Image Optimization
    optimizeImages() {
        this.implementWebP();
        this.addResponsiveImages();
        this.compressImages();
    }
    
    compressImages() {
        const images = document.querySelectorAll('img');
        images.forEach(img => {
            // Add compression attributes
            if (!img.hasAttribute('loading')) {
                img.setAttribute('loading', 'lazy');
            }
            
            // Optimize image quality
            if (img.src && !img.src.includes('?')) {
                const separator = img.src.includes('pexels.com') ? '&' : '?';
                img.src += `${separator}compress=true&quality=85`;
            }
        });
        
        console.log('✅ Image compression applied');
    }
    
    implementWebP() {
        if (this.supportsWebP()) {
            const images = document.querySelectorAll('img');
            images.forEach(img => {
                if (img.src && !img.src.includes('.webp')) {
                    // For Pexels images, we can request WebP format
                    if (img.src.includes('pexels.com')) {
                        img.src = img.src.replace(/\.(jpg|jpeg|png)/, '.webp');
                    }
                }
            });
            
            console.log('🖼️ WebP format implemented');
        }
    }
    
    supportsWebP() {
        const canvas = document.createElement('canvas');
        canvas.width = 1;
        canvas.height = 1;
        return canvas.toDataURL('image/webp').indexOf('data:image/webp') === 0;
    }
    
    addResponsiveImages() {
        const images = document.querySelectorAll('img');
        images.forEach(img => {
            if (!img.srcset && img.src) {
                const baseSrc = img.src.split('?')[0];
                if (baseSrc.includes('pexels.com')) {
                    img.srcset = `
                        ${baseSrc}?w=400 400w,
                        ${baseSrc}?w=800 800w,
                        ${baseSrc}?w=1200 1200w
                    `;
                    img.sizes = '(max-width: 400px) 400px, (max-width: 800px) 800px, 1200px';
                }
            }
        });
        
        console.log('📱 Responsive images implemented');
    }
    
    // Caching Strategy
    setupCaching() {
        this.enableServiceWorker();
        this.setupBrowserCaching();
    }
    
    enableServiceWorker() {
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/sw.js')
                .then(registration => {
                    console.log('✅ Service Worker registered:', registration);
                })
                .catch(error => {
                    console.warn('⚠️ Service Worker not supported in this environment:', error.message);
                });
        }
    }
    
    setupBrowserCaching() {
        // Set cache headers for static resources
        const cacheableResources = [
            { pattern: /\.css$/, maxAge: 31536000 }, // 1 year
            { pattern: /\.js$/, maxAge: 31536000 },  // 1 year
            { pattern: /\.(png|jpg|jpeg|gif|webp)$/, maxAge: 31536000 }, // 1 year
            { pattern: /\.(woff|woff2|ttf|eot)$/, maxAge: 31536000 } // 1 year
        ];
        
        console.log('📦 Browser caching configured');
    }
    
    // HTTP/3 and Modern Protocols
    enableHTTP3() {
        if (this.supportsHTTP3()) {
            console.log('🚀 HTTP/3 support detected');
            this.optimizeForHTTP3();
        } else {
            console.log('📡 Falling back to HTTP/2');
            this.optimizeForHTTP2();
        }
    }
    
    supportsHTTP3() {
        return 'serviceWorker' in navigator && 'fetch' in window;
    }
    
    optimizeForHTTP3() {
        this.enableServerPush();
        this.optimizeResourcePriorities();
    }
    
    enableServerPush() {
        const criticalResources = [
            'src/styles.css',
            'src/script.js',
            'https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Poppins:wght@300;400;500;600;700&display=swap'
        ];
        
        criticalResources.forEach(resource => {
            const link = document.createElement('link');
            link.rel = 'preload';
            link.href = resource;
            link.as = resource.endsWith('.css') ? 'style' : 'script';
            document.head.appendChild(link);
        });
        
        console.log('🚀 Server push enabled for critical resources');
    }
    
    optimizeResourcePriorities() {
        const highPriorityResources = document.querySelectorAll('link[rel="stylesheet"], script[src]');
        highPriorityResources.forEach(resource => {
            if (resource.tagName === 'LINK') {
                resource.setAttribute('importance', 'high');
            } else if (resource.tagName === 'SCRIPT') {
                resource.setAttribute('importance', 'high');
            }
        });
        
        console.log('⚡ Resource priorities optimized');
    }
    
    optimizeForHTTP2() {
        this.enableMultiplexing();
        this.optimizeHeaderCompression();
    }
    
    enableMultiplexing() {
        console.log('🔄 HTTP/2 multiplexing enabled');
    }
    
    optimizeHeaderCompression() {
        console.log('📦 Header compression optimized');
    }
    
    // Resource Optimization
    preloadCriticalResources() {
        const criticalResources = [
            { href: 'src/styles.css', as: 'style' },
            { href: 'src/script.js', as: 'script' },
            { href: 'https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Poppins:wght@300;400;500;600;700&display=swap', as: 'style' }
        ];
        
        criticalResources.forEach(resource => {
            const link = document.createElement('link');
            link.rel = 'preload';
            link.href = resource.href;
            link.as = resource.as;
            document.head.appendChild(link);
        });
    }
    
    optimizeCriticalRenderingPath() {
        // Inline critical CSS
        this.inlineCriticalCSS();
        
        // Defer non-critical CSS
        const nonCriticalCSS = document.querySelectorAll('link[rel="stylesheet"]:not([data-critical])');
        nonCriticalCSS.forEach(link => {
            link.media = 'print';
            link.onload = function() { this.media = 'all'; };
        });
    }
    
    enableResourceHints() {
        const hints = [
            { rel: 'dns-prefetch', href: '//fonts.googleapis.com' },
            { rel: 'dns-prefetch', href: '//images.pexels.com' },
            { rel: 'dns-prefetch', href: '//upload.wikimedia.org' },
            { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossorigin: true }
        ];
        
        hints.forEach(hint => {
            const link = document.createElement('link');
            link.rel = hint.rel;
            link.href = hint.href;
            if (hint.crossorigin) link.crossOrigin = hint.crossorigin;
            document.head.appendChild(link);
        });
    }
    
    // JavaScript Optimization
    deferNonCriticalJavaScript() {
        const nonCriticalScripts = document.querySelectorAll('script[data-defer]');
        nonCriticalScripts.forEach(script => {
            script.defer = true;
        });
    }
    
    useWebWorkers() {
        if ('Worker' in window) {
            try {
                const workerCode = `
                    self.onmessage = function(e) {
                        if (e.data.type === 'optimize') {
                            // Simulate heavy computation
                            let result = 0;
                            for (let i = 0; i < 1000000; i++) {
                                result += Math.random();
                            }
                            self.postMessage({ type: 'optimized', result: result });
                        }
                    };
                `;
                
                const blob = new Blob([workerCode], { type: 'application/javascript' });
                const worker = new Worker(URL.createObjectURL(blob));
                
                worker.postMessage({ type: 'optimize' });
                
                worker.onmessage = (e) => {
                    if (e.data.type === 'optimized') {
                        console.log('✅ Background optimization completed');
                    }
                };
            } catch (error) {
                console.warn('⚠️ Web Worker not available:', error.message);
            }
        }
    }
    
    optimizeEventHandlers() {
        // Debounce scroll events
        let scrollTimeout;
        const originalScrollHandler = window.onscroll;
        
        window.onscroll = function(e) {
            clearTimeout(scrollTimeout);
            scrollTimeout = setTimeout(() => {
                if (originalScrollHandler) {
                    originalScrollHandler.call(this, e);
                }
            }, 16); // ~60fps
        };
    }
    
    // CSS Optimization
    inlineCriticalCSS() {
        const criticalCSS = `
            .loading-spinner { display: flex; position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 9999; }
            .navbar { position: fixed; top: 0; left: 0; right: 0; z-index: 1000; }
            .hero { height: 100vh; display: flex; align-items: center; justify-content: center; }
        `;
        
        const style = document.createElement('style');
        style.textContent = criticalCSS;
        document.head.insertBefore(style, document.head.firstChild);
    }
    
    eliminateRenderBlockingResources() {
        // Make CSS non-render-blocking
        const stylesheets = document.querySelectorAll('link[rel="stylesheet"]');
        stylesheets.forEach(link => {
            if (!link.hasAttribute('data-critical')) {
                link.media = 'print';
                link.onload = function() { this.media = 'all'; };
            }
        });
    }
    
    // Font Optimization
    optimizeFonts() {
        // Use font-display: swap for better performance
        const fontLinks = document.querySelectorAll('link[href*="fonts.googleapis.com"]');
        fontLinks.forEach(link => {
            if (!link.href.includes('display=swap')) {
                link.href += '&display=swap';
            }
        });
        
        // Preload important fonts
        const fontPreloads = [
            'https://fonts.gstatic.com/s/orbitron/v29/yMJMMIlzdpvBhQQL_SC3X9yhF25-T1nyGy6BoWgz.woff2',
            'https://fonts.gstatic.com/s/poppins/v20/pxiEyp8kv8JHgFVrJJfecnFHGPc.woff2'
        ];
        
        fontPreloads.forEach(font => {
            const link = document.createElement('link');
            link.rel = 'preload';
            link.href = font;
            link.as = 'font';
            link.type = 'font/woff2';
            link.crossOrigin = 'anonymous';
            document.head.appendChild(link);
        });
    }
    
    // Layout Optimization
    setImageDimensions() {
        const images = document.querySelectorAll('img:not([width]):not([height])');
        images.forEach(img => {
            // Set default dimensions to prevent layout shift
            if (!img.style.width && !img.style.height) {
                img.style.aspectRatio = '16/9';
                img.style.width = '100%';
                img.style.height = 'auto';
            }
        });
    }
    
    reserveSpaceForAds() {
        const adSlots = document.querySelectorAll('[data-ad-slot]');
        adSlots.forEach(slot => {
            if (!slot.style.minHeight) {
                slot.style.minHeight = '250px';
                slot.style.backgroundColor = '#f0f0f0';
            }
        });
    }
    
    avoidDynamicContent() {
        // Minimize dynamic content insertion that could cause layout shifts
        const dynamicElements = document.querySelectorAll('[data-dynamic]');
        dynamicElements.forEach(element => {
            element.style.minHeight = '100px';
        });
    }
    
    // Service Worker Implementation
    implementServiceWorker() {
        if ('serviceWorker' in navigator) {
            const swCode = `
                const CACHE_NAME = 'sampada-v1';
                const urlsToCache = [
                    '/',
                    '/src/styles.css',
                    '/src/script.js',
                    '/src/ai-security.js',
                    '/src/performance-optimizer.js'
                ];
                
                self.addEventListener('install', event => {
                    event.waitUntil(
                        caches.open(CACHE_NAME)
                            .then(cache => cache.addAll(urlsToCache))
                    );
                });
                
                self.addEventListener('fetch', event => {
                    event.respondWith(
                        caches.match(event.request)
                            .then(response => {
                                if (response) {
                                    return response;
                                }
                                return fetch(event.request);
                            })
                    );
                });
            `;
            
            try {
                const blob = new Blob([swCode], { type: 'application/javascript' });
                const swUrl = URL.createObjectURL(blob);
                
                navigator.serviceWorker.register(swUrl)
                    .then(registration => {
                        console.log('✅ Service Worker registered');
                    })
                    .catch(error => {
                        console.warn('⚠️ Service Worker registration failed:', error.message);
                    });
            } catch (error) {
                console.warn('⚠️ Service Worker not supported:', error.message);
            }
        }
    }
    
    // Performance Monitoring
    setupPerformanceMonitoring() {
        window.addEventListener('load', () => {
            const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
            this.metrics.loadTime = loadTime;
            console.log(`📊 Page load time: ${loadTime}ms`);
            
            this.reportPerformanceMetrics();
        });
        
        this.monitorResourceLoading();
        
        setInterval(() => {
            this.collectPerformanceMetrics();
        }, 30000);
    }
    
    monitorResourceLoading() {
        if ('PerformanceObserver' in window) {
            const observer = new PerformanceObserver((list) => {
                list.getEntries().forEach((entry) => {
                    if (entry.duration > 1000) {
                        console.warn(`⚠️ Slow resource: ${entry.name} took ${entry.duration}ms`);
                    }
                });
            });
            
            observer.observe({ entryTypes: ['resource'] });
        }
    }
    
    collectPerformanceMetrics() {
        const metrics = {
            ...this.metrics,
            memoryUsage: this.getMemoryUsage(),
            connectionType: this.getConnectionType(),
            timestamp: Date.now()
        };
        
        this.storeMetrics(metrics);
        return metrics;
    }
    
    getMemoryUsage() {
        if ('memory' in performance) {
            return {
                used: performance.memory.usedJSHeapSize,
                total: performance.memory.totalJSHeapSize,
                limit: performance.memory.jsHeapSizeLimit
            };
        }
        return null;
    }
    
    getConnectionType() {
        if ('connection' in navigator) {
            return {
                effectiveType: navigator.connection.effectiveType,
                downlink: navigator.connection.downlink,
                rtt: navigator.connection.rtt
            };
        }
        return null;
    }
    
    storeMetrics(metrics) {
        const storedMetrics = JSON.parse(localStorage.getItem('performanceMetrics') || '[]');
        storedMetrics.push(metrics);
        
        if (storedMetrics.length > 100) {
            storedMetrics.splice(0, storedMetrics.length - 100);
        }
        
        localStorage.setItem('performanceMetrics', JSON.stringify(storedMetrics));
    }
    
    reportPerformanceMetrics() {
        const report = {
            loadTime: this.metrics.loadTime,
            fcp: this.metrics.fcp,
            lcp: this.metrics.lcp,
            fid: this.metrics.fid,
            cls: this.metrics.cls,
            grade: this.calculatePerformanceGrade()
        };
        
        console.log('📈 Performance Report:', report);
        return report;
    }
    
    calculatePerformanceGrade() {
        let score = 100;
        
        if (this.metrics.lcp > 2500) score -= 20;
        if (this.metrics.fid > 100) score -= 20;
        if (this.metrics.cls > 0.1) score -= 20;
        if (this.metrics.fcp > 1800) score -= 20;
        if (this.metrics.loadTime > 3000) score -= 20;
        
        if (score >= 90) return 'A';
        if (score >= 80) return 'B';
        if (score >= 70) return 'C';
        if (score >= 60) return 'D';
        return 'F';
    }
    
    // Public API
    getPerformanceReport() {
        return this.reportPerformanceMetrics();
    }
    
    getOptimizationStatus() {
        return this.optimizations;
    }
    
    enableOptimization(type) {
        if (type in this.optimizations) {
            this.optimizations[type] = true;
            console.log(`✅ ${type} optimization enabled`);
        }
    }
    
    disableOptimization(type) {
        if (type in this.optimizations) {
            this.optimizations[type] = false;
            console.log(`❌ ${type} optimization disabled`);
        }
    }
}

// Initialize Performance Optimizer
const performanceOptimizer = new PerformanceOptimizer();

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PerformanceOptimizer;
} else {
    window.PerformanceOptimizer = PerformanceOptimizer;
    window.performanceOptimizer = performanceOptimizer;
}