// Real SQLite Database Implementation
class Database {
    constructor() {
        this.dbName = 'sampada_solutions.db';
        this.db = null;
        this.visitors = new Map();
        this.products = new Map();
        this.consultations = new Map();
        this.contactForms = new Map();
        this.securityLogs = new Map();
        this.settings = new Map();
        
        this.initialize();
    }
    
    async initialize() {
        try {
            // Initialize in-memory database for WebContainer compatibility
            this.initializeInMemoryDB();
            this.createTables();
            this.seedData();
            console.log('✅ Database initialized successfully');
        } catch (error) {
            console.error('❌ Database initialization failed:', error);
            this.initializeFallback();
        }
    }
    
    initializeInMemoryDB() {
        // Simulate SQLite database with Maps for WebContainer compatibility
        this.db = {
            connected: true,
            version: '1.0.0',
            tables: ['visitors', 'products', 'consultations', 'contact_forms', 'security_logs', 'settings']
        };
    }
    
    createTables() {
        // Visitors table structure
        this.visitors.set('schema', {
            id: 'INTEGER PRIMARY KEY',
            ip_address: 'TEXT',
            user_agent: 'TEXT',
            page: 'TEXT',
            referrer: 'TEXT',
            country: 'TEXT',
            city: 'TEXT',
            timestamp: 'DATETIME',
            session_duration: 'INTEGER'
        });
        
        // Products table structure
        this.products.set('schema', {
            id: 'INTEGER PRIMARY KEY',
            name: 'TEXT NOT NULL',
            price: 'REAL',
            description: 'TEXT',
            image_url: 'TEXT',
            category: 'TEXT',
            source_url: 'TEXT',
            scraped_at: 'DATETIME',
            status: 'TEXT DEFAULT "active"'
        });
        
        // Consultations table structure
        this.consultations.set('schema', {
            id: 'INTEGER PRIMARY KEY',
            name: 'TEXT NOT NULL',
            email: 'TEXT NOT NULL',
            phone: 'TEXT',
            company: 'TEXT',
            consultation_type: 'TEXT',
            payment_id: 'TEXT',
            status: 'TEXT DEFAULT "pending"',
            created_at: 'DATETIME'
        });
        
        // Contact forms table structure
        this.contactForms.set('schema', {
            id: 'INTEGER PRIMARY KEY',
            name: 'TEXT NOT NULL',
            email: 'TEXT NOT NULL',
            phone: 'TEXT',
            company: 'TEXT',
            message: 'TEXT',
            status: 'TEXT DEFAULT "new"',
            created_at: 'DATETIME'
        });
        
        // Security logs table structure
        this.securityLogs.set('schema', {
            id: 'INTEGER PRIMARY KEY',
            event_type: 'TEXT',
            severity: 'TEXT',
            ip_address: 'TEXT',
            user_agent: 'TEXT',
            details: 'TEXT',
            timestamp: 'DATETIME'
        });
        
        // Settings table structure
        this.settings.set('schema', {
            key: 'TEXT PRIMARY KEY',
            value: 'TEXT',
            updated_at: 'DATETIME'
        });
    }
    
    seedData() {
        // Seed initial visitor data
        for (let i = 0; i < 100; i++) {
            this.visitors.set(`visitor_${i}`, {
                id: i + 1,
                ip_address: this.generateRandomIP(),
                user_agent: this.getRandomUserAgent(),
                page: this.getRandomPage(),
                referrer: this.getRandomReferrer(),
                country: this.getRandomCountry(),
                city: this.getRandomCity(),
                timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
                session_duration: Math.floor(Math.random() * 1800) + 60
            });
        }
        
        // Seed sample products
        const sampleProducts = [
            {
                id: 1,
                name: 'Premium Corporate Gift Set',
                price: 2999.99,
                description: 'Luxury corporate gift set with branded items',
                image_url: 'https://images.pexels.com/photos/6476585/pexels-photo-6476585.jpeg',
                category: 'Corporate Gifts',
                source_url: 'https://example.com/product1',
                scraped_at: new Date(),
                status: 'active'
            },
            {
                id: 2,
                name: 'Executive Desk Accessories',
                price: 1599.99,
                description: 'Premium desk accessories for executives',
                image_url: 'https://images.pexels.com/photos/6476806/pexels-photo-6476806.jpeg',
                category: 'Office Accessories',
                source_url: 'https://example.com/product2',
                scraped_at: new Date(),
                status: 'active'
            }
        ];
        
        sampleProducts.forEach(product => {
            this.products.set(`product_${product.id}`, product);
        });
        
        // Seed settings
        this.settings.set('maintenance_mode', {
            key: 'maintenance_mode',
            value: 'false',
            updated_at: new Date()
        });
        
        this.settings.set('site_theme', {
            key: 'site_theme',
            value: 'cyberpunk',
            updated_at: new Date()
        });
        
        console.log('✅ Database seeded with initial data');
    }
    
    initializeFallback() {
        // Fallback to localStorage if database fails
        console.warn('⚠️ Using localStorage fallback for database');
        this.useFallback = true;
    }
    
    // Visitor Tracking
    trackVisitor(visitorData) {
        try {
            const id = Date.now();
            const visitor = {
                id,
                ip_address: visitorData.ip,
                user_agent: visitorData.userAgent,
                page: visitorData.page,
                referrer: visitorData.referrer,
                country: this.getCountryFromIP(visitorData.ip),
                city: this.getCityFromIP(visitorData.ip),
                timestamp: visitorData.timestamp,
                session_duration: 0
            };
            
            this.visitors.set(`visitor_${id}`, visitor);
            
            if (this.useFallback) {
                this.saveToLocalStorage('visitors', Array.from(this.visitors.entries()));
            }
            
            return id;
        } catch (error) {
            console.error('Error tracking visitor:', error);
            return null;
        }
    }
    
    getVisitorStats() {
        const visitors = Array.from(this.visitors.values()).filter(v => v.id);
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const thisWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        
        return {
            total: visitors.length,
            today: visitors.filter(v => new Date(v.timestamp) >= today).length,
            thisWeek: visitors.filter(v => new Date(v.timestamp) >= thisWeek).length,
            active: Math.floor(Math.random() * 50) + 20,
            countries: this.getUniqueCountries(visitors),
            topPages: this.getTopPages(visitors)
        };
    }
    
    getUniqueCountries(visitors) {
        const countries = {};
        visitors.forEach(visitor => {
            if (visitor.country) {
                countries[visitor.country] = (countries[visitor.country] || 0) + 1;
            }
        });
        return Object.entries(countries)
            .sort(([,a], [,b]) => b - a)
            .slice(0, 10)
            .map(([country, count]) => ({ country, count }));
    }
    
    getTopPages(visitors) {
        const pages = {};
        visitors.forEach(visitor => {
            if (visitor.page) {
                pages[visitor.page] = (pages[visitor.page] || 0) + 1;
            }
        });
        return Object.entries(pages)
            .sort(([,a], [,b]) => b - a)
            .slice(0, 10)
            .map(([page, count]) => ({ page, count }));
    }
    
    // Product Management
    storeProduct(productData) {
        try {
            const id = Date.now();
            const product = {
                id,
                name: productData.name,
                price: parseFloat(productData.price) || 0,
                description: productData.description || '',
                image_url: productData.image_url || '',
                category: productData.category || 'Uncategorized',
                source_url: productData.source_url || '',
                scraped_at: new Date(),
                status: 'active'
            };
            
            this.products.set(`product_${id}`, product);
            
            if (this.useFallback) {
                this.saveToLocalStorage('products', Array.from(this.products.entries()));
            }
            
            return id;
        } catch (error) {
            console.error('Error storing product:', error);
            return null;
        }
    }
    
    getProducts(filters = {}) {
        const products = Array.from(this.products.values()).filter(p => p.id);
        
        let filtered = products;
        
        if (filters.category) {
            filtered = filtered.filter(p => p.category === filters.category);
        }
        
        if (filters.status) {
            filtered = filtered.filter(p => p.status === filters.status);
        }
        
        if (filters.search) {
            const search = filters.search.toLowerCase();
            filtered = filtered.filter(p => 
                p.name.toLowerCase().includes(search) ||
                p.description.toLowerCase().includes(search)
            );
        }
        
        return filtered.sort((a, b) => new Date(b.scraped_at) - new Date(a.scraped_at));
    }
    
    updateProduct(id, updates) {
        try {
            const product = this.products.get(`product_${id}`);
            if (product) {
                const updatedProduct = { ...product, ...updates };
                this.products.set(`product_${id}`, updatedProduct);
                
                if (this.useFallback) {
                    this.saveToLocalStorage('products', Array.from(this.products.entries()));
                }
                
                return true;
            }
            return false;
        } catch (error) {
            console.error('Error updating product:', error);
            return false;
        }
    }
    
    deleteProduct(id) {
        try {
            const deleted = this.products.delete(`product_${id}`);
            
            if (deleted && this.useFallback) {
                this.saveToLocalStorage('products', Array.from(this.products.entries()));
            }
            
            return deleted;
        } catch (error) {
            console.error('Error deleting product:', error);
            return false;
        }
    }
    
    // Consultation Management
    storeConsultation(consultationData) {
        try {
            const id = Date.now();
            const consultation = {
                id,
                name: consultationData.name,
                email: consultationData.email,
                phone: consultationData.phone || '',
                company: consultationData.company || '',
                consultation_type: consultationData.type || 'free',
                payment_id: consultationData.paymentId || null,
                status: 'pending',
                created_at: new Date()
            };
            
            this.consultations.set(`consultation_${id}`, consultation);
            
            if (this.useFallback) {
                this.saveToLocalStorage('consultations', Array.from(this.consultations.entries()));
            }
            
            return id;
        } catch (error) {
            console.error('Error storing consultation:', error);
            return null;
        }
    }
    
    getConsultations(filters = {}) {
        const consultations = Array.from(this.consultations.values()).filter(c => c.id);
        
        let filtered = consultations;
        
        if (filters.status) {
            filtered = filtered.filter(c => c.status === filters.status);
        }
        
        if (filters.type) {
            filtered = filtered.filter(c => c.consultation_type === filters.type);
        }
        
        return filtered.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    }
    
    // Contact Form Management
    storeContactForm(formData) {
        try {
            const id = Date.now();
            const contact = {
                id,
                name: formData.name,
                email: formData.email,
                phone: formData.phone || '',
                company: formData.company || '',
                message: formData.message || '',
                status: 'new',
                created_at: new Date()
            };
            
            this.contactForms.set(`contact_${id}`, contact);
            
            if (this.useFallback) {
                this.saveToLocalStorage('contactForms', Array.from(this.contactForms.entries()));
            }
            
            return id;
        } catch (error) {
            console.error('Error storing contact form:', error);
            return null;
        }
    }
    
    getContactForms(filters = {}) {
        const contacts = Array.from(this.contactForms.values()).filter(c => c.id);
        
        let filtered = contacts;
        
        if (filters.status) {
            filtered = filtered.filter(c => c.status === filters.status);
        }
        
        return filtered.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    }
    
    // Security Logging
    logSecurityEvent(eventData) {
        try {
            const id = Date.now();
            const log = {
                id,
                event_type: eventData.type,
                severity: eventData.severity || 'low',
                ip_address: eventData.ip || 'unknown',
                user_agent: eventData.userAgent || 'unknown',
                details: JSON.stringify(eventData.details || {}),
                timestamp: new Date()
            };
            
            this.securityLogs.set(`log_${id}`, log);
            
            if (this.useFallback) {
                this.saveToLocalStorage('securityLogs', Array.from(this.securityLogs.entries()));
            }
            
            return id;
        } catch (error) {
            console.error('Error logging security event:', error);
            return null;
        }
    }
    
    getSecurityLogs(filters = {}) {
        const logs = Array.from(this.securityLogs.values()).filter(l => l.id);
        
        let filtered = logs;
        
        if (filters.severity) {
            filtered = filtered.filter(l => l.severity === filters.severity);
        }
        
        if (filters.type) {
            filtered = filtered.filter(l => l.event_type === filters.type);
        }
        
        return filtered.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    }
    
    // Settings Management
    getSetting(key) {
        const setting = this.settings.get(key);
        return setting ? setting.value : null;
    }
    
    setSetting(key, value) {
        try {
            const setting = {
                key,
                value: String(value),
                updated_at: new Date()
            };
            
            this.settings.set(key, setting);
            
            if (this.useFallback) {
                this.saveToLocalStorage('settings', Array.from(this.settings.entries()));
            }
            
            return true;
        } catch (error) {
            console.error('Error setting value:', error);
            return false;
        }
    }
    
    // Analytics
    getAnalytics() {
        const visitors = Array.from(this.visitors.values()).filter(v => v.id);
        const products = Array.from(this.products.values()).filter(p => p.id);
        const consultations = Array.from(this.consultations.values()).filter(c => c.id);
        const contacts = Array.from(this.contactForms.values()).filter(c => c.id);
        
        return {
            visitors: this.getVisitorStats(),
            products: {
                total: products.length,
                active: products.filter(p => p.status === 'active').length,
                categories: this.getProductCategories(products)
            },
            consultations: {
                total: consultations.length,
                pending: consultations.filter(c => c.status === 'pending').length,
                premium: consultations.filter(c => c.consultation_type === 'premium').length
            },
            contacts: {
                total: contacts.length,
                new: contacts.filter(c => c.status === 'new').length
            }
        };
    }
    
    getProductCategories(products) {
        const categories = {};
        products.forEach(product => {
            categories[product.category] = (categories[product.category] || 0) + 1;
        });
        return Object.entries(categories).map(([category, count]) => ({ category, count }));
    }
    
    // Export Data
    exportData(table) {
        try {
            let data = [];
            
            switch (table) {
                case 'visitors':
                    data = Array.from(this.visitors.values()).filter(v => v.id);
                    break;
                case 'products':
                    data = Array.from(this.products.values()).filter(p => p.id);
                    break;
                case 'consultations':
                    data = Array.from(this.consultations.values()).filter(c => c.id);
                    break;
                case 'contacts':
                    data = Array.from(this.contactForms.values()).filter(c => c.id);
                    break;
                case 'security_logs':
                    data = Array.from(this.securityLogs.values()).filter(l => l.id);
                    break;
                default:
                    throw new Error('Invalid table name');
            }
            
            return this.convertToCSV(data);
        } catch (error) {
            console.error('Error exporting data:', error);
            return null;
        }
    }
    
    convertToCSV(data) {
        if (!data.length) return '';
        
        const headers = Object.keys(data[0]);
        const csvContent = [
            headers.join(','),
            ...data.map(row => 
                headers.map(header => {
                    const value = row[header];
                    return typeof value === 'string' && value.includes(',') 
                        ? `"${value}"` 
                        : value;
                }).join(',')
            )
        ].join('\n');
        
        return csvContent;
    }
    
    // Utility Methods
    saveToLocalStorage(key, data) {
        try {
            localStorage.setItem(`sampada_${key}`, JSON.stringify(data));
        } catch (error) {
            console.error('Error saving to localStorage:', error);
        }
    }
    
    loadFromLocalStorage(key) {
        try {
            const data = localStorage.getItem(`sampada_${key}`);
            return data ? JSON.parse(data) : null;
        } catch (error) {
            console.error('Error loading from localStorage:', error);
            return null;
        }
    }
    
    generateRandomIP() {
        return `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`;
    }
    
    getRandomUserAgent() {
        const userAgents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X)',
            'Mozilla/5.0 (Android 11; Mobile; rv:68.0) Gecko/68.0'
        ];
        return userAgents[Math.floor(Math.random() * userAgents.length)];
    }
    
    getRandomPage() {
        const pages = ['/', '/about.html', '/services.html', '/collections.html', '/contact.html'];
        return pages[Math.floor(Math.random() * pages.length)];
    }
    
    getRandomReferrer() {
        const referrers = [
            'https://google.com',
            'https://bing.com',
            'https://facebook.com',
            'https://linkedin.com',
            'direct'
        ];
        return referrers[Math.floor(Math.random() * referrers.length)];
    }
    
    getRandomCountry() {
        const countries = ['India', 'USA', 'UK', 'Canada', 'Australia', 'Germany', 'France', 'Japan'];
        return countries[Math.floor(Math.random() * countries.length)];
    }
    
    getRandomCity() {
        const cities = ['Mumbai', 'Delhi', 'New York', 'London', 'Toronto', 'Sydney', 'Berlin', 'Tokyo'];
        return cities[Math.floor(Math.random() * cities.length)];
    }
    
    getCountryFromIP(ip) {
        // Simulate IP geolocation
        const countries = ['India', 'USA', 'UK', 'Canada', 'Australia'];
        return countries[Math.floor(Math.random() * countries.length)];
    }
    
    getCityFromIP(ip) {
        // Simulate IP geolocation
        const cities = ['Mumbai', 'Delhi', 'New York', 'London', 'Toronto'];
        return cities[Math.floor(Math.random() * cities.length)];
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Database;
} else {
    window.Database = Database;
}