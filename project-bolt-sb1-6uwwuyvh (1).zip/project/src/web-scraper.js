// Advanced Web Scraper for Product Import
class WebScraper {
    constructor() {
        this.database = null;
        this.isScrapingActive = false;
        this.scrapedProducts = [];
        this.supportedSites = [
            'amazon.com',
            'flipkart.com',
            'myntra.com',
            'ajio.com',
            'nykaa.com',
            'shopify.com',
            'woocommerce.com'
        ];
        
        this.initialize();
    }
    
    initialize() {
        // Initialize database connection
        if (window.Database) {
            this.database = new window.Database();
        }
        
        console.log('🕷️ Web Scraper initialized');
    }
    
    // Main scraping function
    async scrapeWebsite(url, selectors = {}) {
        try {
            this.isScrapingActive = true;
            console.log(`🕷️ Starting to scrape: ${url}`);
            
            // Validate URL
            if (!this.isValidURL(url)) {
                throw new Error('Invalid URL provided');
            }
            
            // Check if site is supported
            const siteType = this.detectSiteType(url);
            console.log(`🔍 Detected site type: ${siteType}`);
            
            // Get default selectors for the site
            const defaultSelectors = this.getDefaultSelectors(siteType);
            const finalSelectors = { ...defaultSelectors, ...selectors };
            
            // Simulate scraping (in real implementation, this would use a backend service)
            const products = await this.simulateScraping(url, finalSelectors);
            
            // Process and store products
            const processedProducts = await this.processProducts(products, url);
            
            // Store in database
            if (this.database) {
                for (const product of processedProducts) {
                    await this.database.storeProduct(product);
                }
            }
            
            this.scrapedProducts = [...this.scrapedProducts, ...processedProducts];
            this.isScrapingActive = false;
            
            console.log(`✅ Successfully scraped ${processedProducts.length} products`);
            return {
                success: true,
                products: processedProducts,
                count: processedProducts.length
            };
            
        } catch (error) {
            this.isScrapingActive = false;
            console.error('❌ Scraping failed:', error);
            return {
                success: false,
                error: error.message,
                products: []
            };
        }
    }
    
    // Simulate scraping for demo purposes
    async simulateScraping(url, selectors) {
        return new Promise((resolve) => {
            setTimeout(() => {
                const sampleProducts = this.generateSampleProducts(url);
                resolve(sampleProducts);
            }, 2000); // Simulate network delay
        });
    }
    
    generateSampleProducts(sourceUrl) {
        const sampleProducts = [
            {
                name: 'Premium Corporate Gift Set',
                price: '₹2,999',
                description: 'Luxury corporate gift set with branded items including pen, diary, and desk accessories',
                image: 'https://images.pexels.com/photos/6476585/pexels-photo-6476585.jpeg?auto=compress&cs=tinysrgb&w=400',
                category: 'Corporate Gifts',
                availability: 'In Stock',
                rating: '4.5',
                reviews: '127'
            },
            {
                name: 'Executive Leather Portfolio',
                price: '₹1,599',
                description: 'Premium leather portfolio with multiple compartments for documents and business cards',
                image: 'https://images.pexels.com/photos/6476806/pexels-photo-6476806.jpeg?auto=compress&cs=tinysrgb&w=400',
                category: 'Office Accessories',
                availability: 'In Stock',
                rating: '4.3',
                reviews: '89'
            },
            {
                name: 'Customized Trophy Set',
                price: '₹3,499',
                description: 'Elegant trophy set for corporate awards and recognition ceremonies',
                image: 'https://images.pexels.com/photos/6476807/pexels-photo-6476807.jpeg?auto=compress&cs=tinysrgb&w=400',
                category: 'Awards & Trophies',
                availability: 'In Stock',
                rating: '4.7',
                reviews: '203'
            },
            {
                name: 'Branded Desk Organizer',
                price: '₹899',
                description: 'Wooden desk organizer with company branding options',
                image: 'https://images.pexels.com/photos/6476584/pexels-photo-6476584.jpeg?auto=compress&cs=tinysrgb&w=400',
                category: 'Desk Accessories',
                availability: 'In Stock',
                rating: '4.2',
                reviews: '156'
            },
            {
                name: 'Corporate Welcome Kit',
                price: '₹1,299',
                description: 'Complete welcome kit for new employees with branded merchandise',
                image: 'https://images.pexels.com/photos/6476808/pexels-photo-6476808.jpeg?auto=compress&cs=tinysrgb&w=400',
                category: 'Welcome Kits',
                availability: 'In Stock',
                rating: '4.6',
                reviews: '94'
            }
        ];
        
        // Randomize the products returned
        const count = Math.floor(Math.random() * 5) + 3; // 3-7 products
        return sampleProducts.slice(0, count).map(product => ({
            ...product,
            sourceUrl,
            scrapedAt: new Date()
        }));
    }
    
    // Process scraped products
    async processProducts(products, sourceUrl) {
        const processed = [];
        
        for (const product of products) {
            try {
                const processedProduct = {
                    name: this.cleanText(product.name),
                    price: this.extractPrice(product.price),
                    description: this.cleanText(product.description),
                    image_url: this.validateImageURL(product.image),
                    category: this.cleanText(product.category) || 'Uncategorized',
                    source_url: sourceUrl,
                    availability: product.availability || 'Unknown',
                    rating: product.rating || null,
                    reviews: product.reviews || null,
                    scraped_at: new Date()
                };
                
                // Validate required fields
                if (processedProduct.name && processedProduct.price > 0) {
                    processed.push(processedProduct);
                }
            } catch (error) {
                console.warn('⚠️ Error processing product:', error);
            }
        }
        
        return processed;
    }
    
    // Detect website type
    detectSiteType(url) {
        const domain = new URL(url).hostname.toLowerCase();
        
        if (domain.includes('amazon')) return 'amazon';
        if (domain.includes('flipkart')) return 'flipkart';
        if (domain.includes('myntra')) return 'myntra';
        if (domain.includes('ajio')) return 'ajio';
        if (domain.includes('nykaa')) return 'nykaa';
        if (domain.includes('shopify')) return 'shopify';
        if (domain.includes('woocommerce')) return 'woocommerce';
        
        return 'generic';
    }
    
    // Get default selectors for different sites
    getDefaultSelectors(siteType) {
        const selectors = {
            amazon: {
                productContainer: '[data-component-type="s-search-result"]',
                name: 'h2 a span',
                price: '.a-price-whole',
                image: '.s-image',
                description: '.a-size-base-plus',
                rating: '.a-icon-alt'
            },
            flipkart: {
                productContainer: '._1AtVbE',
                name: '._4rR01T',
                price: '._30jeq3',
                image: '._396cs4',
                description: '._3Djpdu',
                rating: '._3LWZlK'
            },
            myntra: {
                productContainer: '.product-base',
                name: '.product-brand',
                price: '.product-discountedPrice',
                image: '.product-imageSlider img',
                description: '.product-productName',
                rating: '.product-ratingsContainer'
            },
            generic: {
                productContainer: '.product, .item, [class*="product"]',
                name: 'h1, h2, h3, .title, .name, [class*="title"], [class*="name"]',
                price: '.price, [class*="price"], [class*="cost"]',
                image: 'img',
                description: '.description, .desc, [class*="description"]',
                rating: '.rating, [class*="rating"], [class*="star"]'
            }
        };
        
        return selectors[siteType] || selectors.generic;
    }
    
    // Scrape specific product page
    async scrapeProductPage(url) {
        try {
            console.log(`🔍 Scraping product page: ${url}`);
            
            // Simulate detailed product scraping
            const product = await this.simulateProductScraping(url);
            
            if (this.database) {
                await this.database.storeProduct(product);
            }
            
            return {
                success: true,
                product
            };
            
        } catch (error) {
            console.error('❌ Product page scraping failed:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }
    
    async simulateProductScraping(url) {
        return new Promise((resolve) => {
            setTimeout(() => {
                const product = {
                    name: 'Premium Corporate Gift Collection',
                    price: 4999.99,
                    description: 'Comprehensive corporate gift collection featuring premium branded items, custom packaging, and personalization options. Perfect for client appreciation, employee recognition, and business milestones.',
                    image_url: 'https://images.pexels.com/photos/6476585/pexels-photo-6476585.jpeg?auto=compress&cs=tinysrgb&w=800',
                    category: 'Corporate Gifts',
                    source_url: url,
                    availability: 'In Stock',
                    rating: '4.8',
                    reviews: '342',
                    specifications: {
                        material: 'Premium Leather & Metal',
                        dimensions: '30cm x 20cm x 10cm',
                        weight: '1.2kg',
                        customization: 'Available'
                    },
                    scraped_at: new Date()
                };
                
                resolve(product);
            }, 1500);
        });
    }
    
    // Bulk scraping from multiple URLs
    async bulkScrape(urls, options = {}) {
        const results = [];
        const batchSize = options.batchSize || 5;
        const delay = options.delay || 2000;
        
        console.log(`🚀 Starting bulk scrape of ${urls.length} URLs`);
        
        for (let i = 0; i < urls.length; i += batchSize) {
            const batch = urls.slice(i, i + batchSize);
            const batchPromises = batch.map(url => this.scrapeWebsite(url));
            
            try {
                const batchResults = await Promise.all(batchPromises);
                results.push(...batchResults);
                
                console.log(`✅ Completed batch ${Math.floor(i / batchSize) + 1}/${Math.ceil(urls.length / batchSize)}`);
                
                // Delay between batches to avoid overwhelming the server
                if (i + batchSize < urls.length) {
                    await this.delay(delay);
                }
            } catch (error) {
                console.error('❌ Batch scraping error:', error);
            }
        }
        
        const successfulScrapes = results.filter(r => r.success);
        const totalProducts = successfulScrapes.reduce((sum, r) => sum + r.count, 0);
        
        return {
            success: true,
            totalUrls: urls.length,
            successfulScrapes: successfulScrapes.length,
            totalProducts,
            results
        };
    }
    
    // Get scraping status
    getScrapingStatus() {
        return {
            isActive: this.isScrapingActive,
            totalScraped: this.scrapedProducts.length,
            lastScrapeTime: this.scrapedProducts.length > 0 
                ? Math.max(...this.scrapedProducts.map(p => new Date(p.scraped_at).getTime()))
                : null,
            supportedSites: this.supportedSites
        };
    }
    
    // Get scraped products
    getScrapedProducts(filters = {}) {
        let products = [...this.scrapedProducts];
        
        if (filters.category) {
            products = products.filter(p => p.category === filters.category);
        }
        
        if (filters.minPrice) {
            products = products.filter(p => p.price >= filters.minPrice);
        }
        
        if (filters.maxPrice) {
            products = products.filter(p => p.price <= filters.maxPrice);
        }
        
        if (filters.search) {
            const search = filters.search.toLowerCase();
            products = products.filter(p => 
                p.name.toLowerCase().includes(search) ||
                p.description.toLowerCase().includes(search)
            );
        }
        
        return products.sort((a, b) => new Date(b.scraped_at) - new Date(a.scraped_at));
    }
    
    // Export scraped products
    exportProducts(format = 'csv') {
        try {
            const products = this.getScrapedProducts();
            
            if (format === 'csv') {
                return this.convertToCSV(products);
            } else if (format === 'json') {
                return JSON.stringify(products, null, 2);
            } else {
                throw new Error('Unsupported export format');
            }
        } catch (error) {
            console.error('❌ Export failed:', error);
            return null;
        }
    }
    
    convertToCSV(products) {
        if (!products.length) return '';
        
        const headers = ['Name', 'Price', 'Category', 'Description', 'Image URL', 'Source URL', 'Scraped At'];
        const csvContent = [
            headers.join(','),
            ...products.map(product => [
                `"${product.name}"`,
                product.price,
                `"${product.category}"`,
                `"${product.description}"`,
                `"${product.image_url}"`,
                `"${product.source_url}"`,
                `"${product.scraped_at}"`
            ].join(','))
        ].join('\n');
        
        return csvContent;
    }
    
    // Clear scraped data
    clearScrapedData() {
        this.scrapedProducts = [];
        console.log('🗑️ Scraped data cleared');
    }
    
    // Utility methods
    isValidURL(string) {
        try {
            new URL(string);
            return true;
        } catch (_) {
            return false;
        }
    }
    
    cleanText(text) {
        if (!text) return '';
        return text.toString().trim().replace(/\s+/g, ' ');
    }
    
    extractPrice(priceText) {
        if (!priceText) return 0;
        
        // Remove currency symbols and extract number
        const cleaned = priceText.toString().replace(/[^\d.,]/g, '');
        const number = parseFloat(cleaned.replace(/,/g, ''));
        
        return isNaN(number) ? 0 : number;
    }
    
    validateImageURL(url) {
        if (!url) return '';
        
        try {
            new URL(url);
            return url;
        } catch (_) {
            return '';
        }
    }
    
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    // Advanced scraping features
    async scrapeWithPagination(baseUrl, maxPages = 10) {
        const allProducts = [];
        
        for (let page = 1; page <= maxPages; page++) {
            try {
                const pageUrl = `${baseUrl}${baseUrl.includes('?') ? '&' : '?'}page=${page}`;
                const result = await this.scrapeWebsite(pageUrl);
                
                if (result.success && result.products.length > 0) {
                    allProducts.push(...result.products);
                    console.log(`📄 Scraped page ${page}: ${result.products.length} products`);
                } else {
                    console.log(`🛑 No more products found at page ${page}`);
                    break;
                }
                
                // Delay between pages
                await this.delay(1000);
                
            } catch (error) {
                console.error(`❌ Error scraping page ${page}:`, error);
                break;
            }
        }
        
        return {
            success: true,
            totalProducts: allProducts.length,
            products: allProducts
        };
    }
    
    // Schedule scraping
    scheduleScrapingJob(urls, interval = 3600000) { // Default: 1 hour
        const jobId = setInterval(async () => {
            console.log('⏰ Running scheduled scraping job');
            await this.bulkScrape(urls);
        }, interval);
        
        console.log(`📅 Scheduled scraping job created with ID: ${jobId}`);
        return jobId;
    }
    
    cancelScrapingJob(jobId) {
        clearInterval(jobId);
        console.log(`❌ Cancelled scraping job: ${jobId}`);
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = WebScraper;
} else {
    window.WebScraper = WebScraper;
}